(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/Creator-Control-Room_3c9a2449._.js",
  "static/chunks/80260_next_5d087a5e._.js",
  "static/chunks/80260_lodash_c5c1c3df._.js",
  "static/chunks/80260_recharts_es6_6ce10779._.js",
  "static/chunks/80260_tailwind-merge_dist_bundle-mjs_mjs_b5944ca4._.js",
  "static/chunks/80260_d5953960._.js"
],
    source: "dynamic"
});
