(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/Creator-Control-Room/frontend/app/components/sideBar.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Creator-Control-Room/frontend/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Creator-Control-Room/frontend/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Creator-Control-Room/frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
function SideBar(param) {
    let { onAction } = param;
    _s();
    const [dropdown, setDropdown] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const params = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSearchParams"])();
    const company_id = params.get("company_id");
    const company_name = params.get("company_name");
    const itemClicked = (widgetName)=>{
        onAction({
            widgetName: widgetName,
            widgetState: true
        });
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "bg-[var(--widget)] grid grid-cols-auto auto-rows-min shrink-0 h-full py-7",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                className: "h-10 text-sm rounded-[5px] hover:bg-[var(--hover)] active:bg-[var(--button)] align-middle font-semibold ",
                onClick: ()=>{
                    router.push("/streamerAuth?company_id=".concat(company_id, "&company_name=").concat(company_name));
                },
                children: "Add Creator +"
            }, void 0, false, {
                fileName: "[project]/Creator-Control-Room/frontend/app/components/sideBar.tsx",
                lineNumber: 28,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                onClick: ()=>setDropdown(!dropdown),
                className: "h-10 text-sm font-semibold align-middle rounded-[5px] transition ".concat(dropdown ? "bg-[var(--button)]" : "bg-[var(--widget)] hover:bg-[var(--hover)]", " "),
                children: [
                    " ",
                    "Add Widget +"
                ]
            }, void 0, true, {
                fileName: "[project]/Creator-Control-Room/frontend/app/components/sideBar.tsx",
                lineNumber: 39,
                columnNumber: 7
            }, this),
            dropdown && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: " w-full origin-top-right rounded-sm shadow-lg ring-1 ring-black ring-opacity-5",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "py-1 text-center",
                    children: [
                        " ",
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                            onClick: ()=>itemClicked("cheer"),
                            href: "#",
                            className: "block px-4 py-2 text-sm  hover:bg-[var(--hover)]",
                            children: "Add Cheer Widget"
                        }, void 0, false, {
                            fileName: "[project]/Creator-Control-Room/frontend/app/components/sideBar.tsx",
                            lineNumber: 55,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                            "data-testid": "add me",
                            onClick: ()=>itemClicked("gift"),
                            href: "#",
                            className: "block px-4 py-2 text-sm  hover:bg-[var(--hover)]",
                            children: "Add Gifted Widget"
                        }, void 0, false, {
                            fileName: "[project]/Creator-Control-Room/frontend/app/components/sideBar.tsx",
                            lineNumber: 62,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                            onClick: ()=>itemClicked("subscribe"),
                            href: "#",
                            className: "block px-4 py-2 text-sm  hover:bg-[var(--hover)]",
                            children: "Add Subscriber Widget"
                        }, void 0, false, {
                            fileName: "[project]/Creator-Control-Room/frontend/app/components/sideBar.tsx",
                            lineNumber: 70,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                            onClick: ()=>itemClicked("bits"),
                            href: "#",
                            className: "block px-4 py-2 text-sm  hover:bg-[var(--hover)]",
                            children: "Add Bits Widget"
                        }, void 0, false, {
                            fileName: "[project]/Creator-Control-Room/frontend/app/components/sideBar.tsx",
                            lineNumber: 77,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                            onClick: ()=>itemClicked("follow"),
                            href: "#",
                            className: "block px-4 py-2 text-sm  hover:bg-[var(--hover)]",
                            children: "Add New Follower Widget"
                        }, void 0, false, {
                            fileName: "[project]/Creator-Control-Room/frontend/app/components/sideBar.tsx",
                            lineNumber: 84,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/Creator-Control-Room/frontend/app/components/sideBar.tsx",
                    lineNumber: 52,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/Creator-Control-Room/frontend/app/components/sideBar.tsx",
                lineNumber: 51,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/Creator-Control-Room/frontend/app/components/sideBar.tsx",
        lineNumber: 27,
        columnNumber: 5
    }, this);
}
_s(SideBar, "CWjfRBP1Ue6ZWcpqgHswyh5592w=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"],
        __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSearchParams"]
    ];
});
_c = SideBar;
const __TURBOPACK__default__export__ = SideBar;
var _c;
__turbopack_context__.k.register(_c, "SideBar");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/Creator-Control-Room/frontend/app/components/signout.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Signout
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Creator-Control-Room/frontend/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Creator-Control-Room/frontend/node_modules/next/navigation.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
function Signout() {
    _s();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    // LIST OF PAYLOAD TYPES
    const onClick = ()=>{
        router.push("/signup");
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        children: [
            " ",
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                className: "rounded-sm p-1 bg-[var(--button)]",
                onClick: onClick,
                children: [
                    " ",
                    "Sign out"
                ]
            }, void 0, true, {
                fileName: "[project]/Creator-Control-Room/frontend/app/components/signout.tsx",
                lineNumber: 13,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/Creator-Control-Room/frontend/app/components/signout.tsx",
        lineNumber: 11,
        columnNumber: 5
    }, this);
}
_s(Signout, "fN7XvhJ+p5oE6+Xlo0NJmXpxjC8=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"]
    ];
});
_c = Signout;
var _c;
__turbopack_context__.k.register(_c, "Signout");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/Creator-Control-Room/frontend/app/components/navBar.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Creator-Control-Room/frontend/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Creator-Control-Room/frontend/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$app$2f$components$2f$signout$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Creator-Control-Room/frontend/app/components/signout.tsx [app-client] (ecmascript)");
;
;
;
function NavBar(param) {
    let { logourl, company_name } = param;
    console.log(logourl);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("nav", {
        className: "bg-[var(--widget)] dark:bg-gray-900 fixed w-full z-20 top-0 start-0 border-b border-gray-200 dark:border-gray-600",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "max-w-screen-xl flex flex-wrap items-center justify-between mx-auto p-4",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                    href: "https://flowbite.com/",
                    className: "flex items-center space-x-3 rtl:space-x-reverse",
                    children: [
                        logourl && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            src: logourl,
                            className: "h-8",
                            alt: "Flowbite Logo",
                            width: 32,
                            height: 32
                        }, void 0, false, {
                            fileName: "[project]/Creator-Control-Room/frontend/app/components/navBar.tsx",
                            lineNumber: 18,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "self-center text-2xl font-semibold whitespace-nowrap dark:text-white",
                            children: company_name
                        }, void 0, false, {
                            fileName: "[project]/Creator-Control-Room/frontend/app/components/navBar.tsx",
                            lineNumber: 26,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/Creator-Control-Room/frontend/app/components/navBar.tsx",
                    lineNumber: 13,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex md:order-2 space-x-3 md:space-x-0 rtl:space-x-reverse",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$app$2f$components$2f$signout$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                        fileName: "[project]/Creator-Control-Room/frontend/app/components/navBar.tsx",
                        lineNumber: 31,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/Creator-Control-Room/frontend/app/components/navBar.tsx",
                    lineNumber: 30,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "items-center justify-between hidden w-full md:flex md:w-auto md:order-1",
                    id: "navbar-sticky"
                }, void 0, false, {
                    fileName: "[project]/Creator-Control-Room/frontend/app/components/navBar.tsx",
                    lineNumber: 33,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/Creator-Control-Room/frontend/app/components/navBar.tsx",
            lineNumber: 12,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/Creator-Control-Room/frontend/app/components/navBar.tsx",
        lineNumber: 11,
        columnNumber: 5
    }, this);
}
_c = NavBar;
const __TURBOPACK__default__export__ = NavBar;
var _c;
__turbopack_context__.k.register(_c, "NavBar");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/Creator-Control-Room/backend/tests/payload.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

//The channel.follow subscription type sends a notification when a specified channel receives a follow.
// broadcaster is the streamer
// moderator is the moderator auth, it can be broadcaster too
// User is the viewer doing the action/triggering the event
__turbopack_context__.s([
    "bits_payload",
    ()=>bits_payload,
    "cheer_payload",
    ()=>cheer_payload,
    "follow_payload",
    ()=>follow_payload,
    "gifted_payload",
    ()=>gifted_payload,
    "raid_payload",
    ()=>raid_payload,
    "subscriber_payload",
    ()=>subscriber_payload
]);
const follow_payload = {
    subscription: {
        id: "f1c2a387-161a-49f9-a165-0f21d7a4e1c4",
        type: "channel.follow",
        version: "2",
        status: "enabled",
        cost: 0,
        condition: {
            broadcaster_user_id: "1337",
            moderator_user_id: "1337"
        },
        transport: {
            method: "webhook",
            callback: "https://example.com/webhooks/callback"
        },
        created_at: "2019-11-16T10:11:12.634234626Z"
    },
    event: {
        user_id: "1234",
        user_login: "cool_user",
        user_name: "Cool_User",
        broadcaster_user_id: "1337",
        broadcaster_user_login: "cooler_user",
        broadcaster_user_name: "Cooler_User",
        followed_at: "2020-07-15T18:16:11.17106713Z"
    }
};
const bits_payload = {
    subscription: {
        id: "f1c2a387-161a-49f9-a165-0f21d7a4e1c4",
        type: "channel.bits.use",
        version: "1",
        status: "enabled",
        cost: 0,
        condition: {
            broadcaster_user_id: "1337"
        },
        transport: {
            method: "webhook",
            callback: "https://example.com/webhooks/callback"
        },
        created_at: "2019-11-16T10:11:12.634234626Z"
    },
    event: {
        user_id: "1234",
        user_login: "cool_user",
        user_name: "Cool_User",
        broadcaster_user_id: "1337",
        broadcaster_user_login: "cooler_user",
        broadcaster_user_name: "Cooler_User",
        bits: 2,
        type: "cheer",
        power_up: null,
        message: {
            text: "cheer1 hi cheer1",
            fragments: [
                {
                    type: "cheermote",
                    text: "cheer1",
                    cheermote: {
                        prefix: "cheer",
                        bits: 1,
                        tier: 1
                    },
                    emote: null
                },
                {
                    type: "text",
                    text: " hi ",
                    cheermote: null,
                    emote: null
                },
                {
                    type: "cheermote",
                    text: "cheer1",
                    cheermote: {
                        prefix: "cheer",
                        bits: 1,
                        tier: 1
                    },
                    emote: null
                }
            ]
        }
    }
};
const subscriber_payload = {
    subscription: {
        id: "f1c2a387-161a-49f9-a165-0f21d7a4e1c4",
        type: "channel.subscribe",
        version: "1",
        status: "enabled",
        cost: 0,
        condition: {
            broadcaster_user_id: "1337"
        },
        transport: {
            method: "webhook",
            callback: "https://example.com/webhooks/callback"
        },
        created_at: "2019-11-16T10:11:12.634234626Z"
    },
    event: {
        user_id: "1234",
        user_login: "cool_user",
        user_name: "Cool_User",
        broadcaster_user_id: "1337",
        broadcaster_user_login: "cooler_user",
        broadcaster_user_name: "Cooler_User",
        tier: "1000",
        is_gift: false
    }
};
const gifted_payload = {
    subscription: {
        id: "f1c2a387-161a-49f9-a165-0f21d7a4e1c4",
        type: "channel.subscription.gift",
        version: "1",
        status: "enabled",
        cost: 0,
        condition: {
            broadcaster_user_id: "1337"
        },
        transport: {
            method: "webhook",
            callback: "https://example.com/webhooks/callback"
        },
        created_at: "2019-11-16T10:11:12.634234626Z"
    },
    event: {
        user_id: "1234",
        user_login: "cool_user",
        user_name: "Cool_User",
        broadcaster_user_id: "1337",
        broadcaster_user_login: "cooler_user",
        broadcaster_user_name: "Cooler_User",
        total: 2,
        tier: "1000",
        cumulative_total: 284,
        is_anonymous: false
    }
};
const cheer_payload = {
    subscription: {
        id: "f1c2a387-161a-49f9-a165-0f21d7a4e1c4",
        type: "channel.cheer",
        version: "1",
        status: "enabled",
        cost: 0,
        condition: {
            broadcaster_user_id: "1337"
        },
        transport: {
            method: "webhook",
            callback: "https://example.com/webhooks/callback"
        },
        created_at: "2019-11-16T10:11:12.634234626Z"
    },
    event: {
        is_anonymous: false,
        user_id: "1234",
        user_login: "cool_user",
        user_name: "Cool_User",
        broadcaster_user_id: "1337",
        broadcaster_user_login: "cooler_user",
        broadcaster_user_name: "Cooler_User",
        message: "pogchamp",
        bits: 1000
    }
};
const raid_payload = {
    subscription: {
        id: "f1c2a387-161a-49f9-a165-0f21d7a4e1c4",
        type: "channel.raid",
        version: "1",
        status: "enabled",
        cost: 0,
        condition: {
            to_broadcaster_user_id: "1337"
        },
        transport: {
            method: "webhook",
            callback: "https://example.com/webhooks/callback"
        },
        created_at: "2019-11-16T10:11:12.634234626Z"
    },
    event: {
        from_broadcaster_user_id: "1234",
        from_broadcaster_user_login: "cool_user",
        from_broadcaster_user_name: "Cool_User",
        to_broadcaster_user_id: "1337",
        to_broadcaster_user_login: "cooler_user",
        to_broadcaster_user_name: "Cooler_User",
        viewers: 9001
    }
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/Creator-Control-Room/frontend/app/components/generateEvents.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// import { generateKey } from "crypto";
// import { Dispatch, SetStateAction } from "react";
__turbopack_context__.s([
    "default",
    ()=>GenerateEvent
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Creator-Control-Room/frontend/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$backend$2f$tests$2f$payload$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Creator-Control-Room/backend/tests/payload.js [app-client] (ecmascript)");
;
;
function GenerateEvent(param) {
    let { onAction } = param;
    // LIST OF PAYLOAD TYPES
    const payload_list = [
        __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$backend$2f$tests$2f$payload$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["follow_payload"],
        __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$backend$2f$tests$2f$payload$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bits_payload"],
        __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$backend$2f$tests$2f$payload$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["raid_payload"],
        __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$backend$2f$tests$2f$payload$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cheer_payload"],
        __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$backend$2f$tests$2f$payload$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["subscriber_payload"],
        __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$backend$2f$tests$2f$payload$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["gifted_payload"]
    ];
    const getEvents = async ()=>{
        console.log("Pow");
        const response = await fetch("https://a0c2b18f2a76.ngrok-free.app/db/events", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                hi: "hello"
            })
        });
        console.log("show");
        const data = await response.json();
        console.log(data);
        console.log("brow");
    };
    // GENERATE RANDOM NUMBER
    function getRandomInt(min, max) {
        min = Math.ceil(min);
        max = Math.floor(max);
        return Math.floor(Math.random() * (max - min + 1)) + min;
    }
    // ON CLICK SEND DATA TO THE ONACTION PROP
    const generateEvent = ()=>{
        const index = getRandomInt(0, payload_list.length - 1);
        onAction(payload_list[index]);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        children: [
            " ",
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                onClick: generateEvent,
                children: "Generate Event"
            }, void 0, false, {
                fileName: "[project]/Creator-Control-Room/frontend/app/components/generateEvents.tsx",
                lineNumber: 59,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                onClick: getEvents,
                children: "Get Event"
            }, void 0, false, {
                fileName: "[project]/Creator-Control-Room/frontend/app/components/generateEvents.tsx",
                lineNumber: 60,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/Creator-Control-Room/frontend/app/components/generateEvents.tsx",
        lineNumber: 57,
        columnNumber: 5
    }, this);
}
_c = GenerateEvent;
var _c;
__turbopack_context__.k.register(_c, "GenerateEvent");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/Creator-Control-Room/frontend/app/components/eventsNoti.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// import React, { useState } from "react";
__turbopack_context__.s([
    "default",
    ()=>EventsNoti
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Creator-Control-Room/frontend/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
;
function EventsNoti(event) {
    //   const [creatorName, setCreatorName] = useState<string>("");
    let text = "Error unreadable type";
    switch(event.type){
        case "follow":
            text = "".concat(event.user_name, " followed ").concat(event.broadcaster_user_name);
            break;
        case "subscribe":
            text = "".concat(event.user_name, " subscribed to ").concat(event.broadcaster_user_name);
            break;
        case "cheer":
            text = "".concat(event.user_name, " cheered ").concat(event.bits, " bits in ").concat(event.broadcaster_user_name, "'s chat: ").concat(event.message);
            break;
        case "bits":
            text = "".concat(event.user_name, " gave ").concat(event.bits, " bits to ").concat(event.broadcaster_user_name);
            break;
        case "raid":
            text = "".concat(event.from_broadcaster_user_name, " RAIDED ").concat(event.to_broadcaster_user_name, " with ").concat(event.viewers, " viewers!");
            break;
        case "gift":
            text = "".concat(event.user_name, " gifted ").concat(event.total, " subs in ").concat(event.broadcaster_user_name, "'s chat");
            break;
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex bg-[#18181b] border-b-1 border-gray-500 h-auto top-0 z-10 gap-2 pt-3 pb-4",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            children: text
        }, void 0, false, {
            fileName: "[project]/Creator-Control-Room/frontend/app/components/eventsNoti.tsx",
            lineNumber: 36,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/Creator-Control-Room/frontend/app/components/eventsNoti.tsx",
        lineNumber: 35,
        columnNumber: 5
    }, this);
}
_c = EventsNoti;
var _c;
__turbopack_context__.k.register(_c, "EventsNoti");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/Creator-Control-Room/frontend/app/components/widgets/bitsWidget.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>GiftedWidget
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Creator-Control-Room/frontend/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$app$2f$components$2f$eventsNoti$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Creator-Control-Room/frontend/app/components/eventsNoti.tsx [app-client] (ecmascript)");
;
;
function GiftedWidget(param) {
    let { events, show, onAction } = param;
    const widgetClicked = ()=>{
        console.log("WIDGET SET TO DELETE");
        onAction({
            widgetName: "bits",
            widgetState: false
        });
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: show && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "w-full h-64 grid grid-rows-[auto_1fr] gap-0.5",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "bg-[#26262b] flex justify-between w-full p-2 max-h-10",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "font-bold",
                            children: "Bits Feed"
                        }, void 0, false, {
                            fileName: "[project]/Creator-Control-Room/frontend/app/components/widgets/bitsWidget.tsx",
                            lineNumber: 31,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            className: "bg-[var(--button)] hover:bg-violet-500 px-3 rounded transition",
                            onClick: widgetClicked,
                            children: "delete"
                        }, void 0, false, {
                            fileName: "[project]/Creator-Control-Room/frontend/app/components/widgets/bitsWidget.tsx",
                            lineNumber: 32,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/Creator-Control-Room/frontend/app/components/widgets/bitsWidget.tsx",
                    lineNumber: 30,
                    columnNumber: 11
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "bg-[#18181b] h-full overflow-y-auto grid grid-cols-1 auto-rows-min gap-1 pl-1 pr-1",
                    children: events.map((event, id)=>{
                        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$app$2f$components$2f$eventsNoti$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            ...event
                        }, id, false, {
                            fileName: "[project]/Creator-Control-Room/frontend/app/components/widgets/bitsWidget.tsx",
                            lineNumber: 42,
                            columnNumber: 22
                        }, this);
                    })
                }, void 0, false, {
                    fileName: "[project]/Creator-Control-Room/frontend/app/components/widgets/bitsWidget.tsx",
                    lineNumber: 40,
                    columnNumber: 11
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/Creator-Control-Room/frontend/app/components/widgets/bitsWidget.tsx",
            lineNumber: 29,
            columnNumber: 9
        }, this)
    }, void 0, false);
}
_c = GiftedWidget;
var _c;
__turbopack_context__.k.register(_c, "GiftedWidget");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/Creator-Control-Room/frontend/app/components/widgets/cheerWidget.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>CheerWidget
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Creator-Control-Room/frontend/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$app$2f$components$2f$eventsNoti$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Creator-Control-Room/frontend/app/components/eventsNoti.tsx [app-client] (ecmascript)");
;
;
function CheerWidget(param) {
    let { events, show, onAction } = param;
    const widgetClicked = ()=>{
        console.log("WIDGET SET TO DELETE");
        onAction({
            widgetName: "cheer",
            widgetState: false
        });
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: show && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "w-full h-64 grid grid-rows-[auto_1fr] gap-0.5",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "bg-[#26262b] flex justify-between w-full p-2 max-h-10",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "font-bold",
                            children: "Cheer Feed"
                        }, void 0, false, {
                            fileName: "[project]/Creator-Control-Room/frontend/app/components/widgets/cheerWidget.tsx",
                            lineNumber: 34,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            className: "bg-[var(--button)] hover:bg-violet-500 px-3 rounded transition",
                            onClick: widgetClicked,
                            children: "delete"
                        }, void 0, false, {
                            fileName: "[project]/Creator-Control-Room/frontend/app/components/widgets/cheerWidget.tsx",
                            lineNumber: 35,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/Creator-Control-Room/frontend/app/components/widgets/cheerWidget.tsx",
                    lineNumber: 33,
                    columnNumber: 11
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "bg-[#18181b] h-full overflow-y-auto grid grid-cols-1 auto-rows-min gap-1 pl-1 pr-1",
                    children: events.map((event, id)=>{
                        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$app$2f$components$2f$eventsNoti$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            ...event
                        }, id, false, {
                            fileName: "[project]/Creator-Control-Room/frontend/app/components/widgets/cheerWidget.tsx",
                            lineNumber: 44,
                            columnNumber: 22
                        }, this);
                    })
                }, void 0, false, {
                    fileName: "[project]/Creator-Control-Room/frontend/app/components/widgets/cheerWidget.tsx",
                    lineNumber: 42,
                    columnNumber: 11
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/Creator-Control-Room/frontend/app/components/widgets/cheerWidget.tsx",
            lineNumber: 32,
            columnNumber: 9
        }, this)
    }, void 0, false);
}
_c = CheerWidget;
var _c;
__turbopack_context__.k.register(_c, "CheerWidget");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/Creator-Control-Room/frontend/app/components/liveCreator.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Creator-Control-Room/frontend/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Creator-Control-Room/frontend/node_modules/next/image.js [app-client] (ecmascript)");
;
;
function LiveCreator(param) {
    let { creator } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex bg-[#18181b] border-b-1 border-gray-500 h-12 top-0 z-10 gap-2 pt-3 pb-4",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    src: creator.logo,
                    alt: "".concat(creator.name, " logo"),
                    width: 30,
                    height: 30
                }, void 0, false, {
                    fileName: "[project]/Creator-Control-Room/frontend/app/components/liveCreator.tsx",
                    lineNumber: 15,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    children: [
                        creator.name,
                        " is live"
                    ]
                }, void 0, true, {
                    fileName: "[project]/Creator-Control-Room/frontend/app/components/liveCreator.tsx",
                    lineNumber: 21,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/Creator-Control-Room/frontend/app/components/liveCreator.tsx",
            lineNumber: 14,
            columnNumber: 7
        }, this)
    }, void 0, false);
}
_c = LiveCreator;
const __TURBOPACK__default__export__ = LiveCreator;
var _c;
__turbopack_context__.k.register(_c, "LiveCreator");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/Creator-Control-Room/frontend/app/components/widgets/creatorsLive.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Creator-Control-Room/frontend/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Creator-Control-Room/frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$app$2f$components$2f$liveCreator$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Creator-Control-Room/frontend/app/components/liveCreator.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
function CreatorsLive(param) {
    let { creators } = param;
    _s();
    const [liveCount, setLiveCount] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    // Updates liveCount when creators prop changes
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "CreatorsLive.useEffect": ()=>{
            if (creators) {
                setLiveCount(creators.length);
            } else {
                setLiveCount(0);
            }
        }
    }["CreatorsLive.useEffect"], [
        creators
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "w-full h-64 grid grid-rows-[auto_1fr] gap-0.5",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "bg-[#26262b] p-2 max-h-10 ",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "font-bold ",
                    children: [
                        "Number of creators live: ",
                        liveCount
                    ]
                }, void 0, true, {
                    fileName: "[project]/Creator-Control-Room/frontend/app/components/widgets/creatorsLive.tsx",
                    lineNumber: 27,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/Creator-Control-Room/frontend/app/components/widgets/creatorsLive.tsx",
                lineNumber: 26,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "bg-[#18181b] h-full overflow-y-auto grid grid-cols-1 auto-rows-min gap-1 pl-1 pr-1",
                children: creators ? creators.map((creator, id)=>{
                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$app$2f$components$2f$liveCreator$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        creator: creator
                    }, id, false, {
                        fileName: "[project]/Creator-Control-Room/frontend/app/components/widgets/creatorsLive.tsx",
                        lineNumber: 32,
                        columnNumber: 22
                    }, this);
                }) : []
            }, void 0, false, {
                fileName: "[project]/Creator-Control-Room/frontend/app/components/widgets/creatorsLive.tsx",
                lineNumber: 29,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/Creator-Control-Room/frontend/app/components/widgets/creatorsLive.tsx",
        lineNumber: 25,
        columnNumber: 5
    }, this);
}
_s(CreatorsLive, "aIba8wz8lMuMmPVB6O9otw6AXWk=");
_c = CreatorsLive;
const __TURBOPACK__default__export__ = CreatorsLive;
var _c;
__turbopack_context__.k.register(_c, "CreatorsLive");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/Creator-Control-Room/frontend/app/components/widgets/eventsWidget.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>EventsWidget
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Creator-Control-Room/frontend/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$app$2f$components$2f$eventsNoti$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Creator-Control-Room/frontend/app/components/eventsNoti.tsx [app-client] (ecmascript)");
;
;
function EventsWidget(param) {
    let { events } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "w-full h-full  grid grid-rows-[auto_1fr] gap-0.5",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "bg-[#26262b] p-2 max-h-10 ",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "font-bold",
                    children: "Activity Feed"
                }, void 0, false, {
                    fileName: "[project]/Creator-Control-Room/frontend/app/components/widgets/eventsWidget.tsx",
                    lineNumber: 8,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/Creator-Control-Room/frontend/app/components/widgets/eventsWidget.tsx",
                lineNumber: 7,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "bg-[#18181b] h-full overflow-y-auto grid grid-cols-1 auto-rows-min gap-1 pl-1 pr-1",
                children: events.map((event, id)=>{
                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$app$2f$components$2f$eventsNoti$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        ...event
                    }, id, false, {
                        fileName: "[project]/Creator-Control-Room/frontend/app/components/widgets/eventsWidget.tsx",
                        lineNumber: 12,
                        columnNumber: 18
                    }, this);
                })
            }, void 0, false, {
                fileName: "[project]/Creator-Control-Room/frontend/app/components/widgets/eventsWidget.tsx",
                lineNumber: 10,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/Creator-Control-Room/frontend/app/components/widgets/eventsWidget.tsx",
        lineNumber: 6,
        columnNumber: 5
    }, this);
}
_c = EventsWidget;
var _c;
__turbopack_context__.k.register(_c, "EventsWidget");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/Creator-Control-Room/frontend/app/components/widgets/giftedWidget.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>GiftedWidget
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Creator-Control-Room/frontend/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$app$2f$components$2f$eventsNoti$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Creator-Control-Room/frontend/app/components/eventsNoti.tsx [app-client] (ecmascript)");
;
;
function GiftedWidget(param) {
    let { events, show, onAction } = param;
    const widgetClicked = ()=>{
        console.log("WIDGET SET TO DELETE");
        onAction({
            widgetName: "gift",
            widgetState: false
        });
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: show && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "w-full h-64 grid grid-rows-[auto_1fr] gap-0.5",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "bg-[#26262b] flex justify-between w-full p-2 max-h-10",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "font-bold",
                            children: "Gifted Feed"
                        }, void 0, false, {
                            fileName: "[project]/Creator-Control-Room/frontend/app/components/widgets/giftedWidget.tsx",
                            lineNumber: 31,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            "data-testid": "delete me",
                            className: "bg-[var(--button)] hover:bg-violet-500 px-3 rounded transition",
                            onClick: widgetClicked,
                            children: "delete"
                        }, void 0, false, {
                            fileName: "[project]/Creator-Control-Room/frontend/app/components/widgets/giftedWidget.tsx",
                            lineNumber: 32,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/Creator-Control-Room/frontend/app/components/widgets/giftedWidget.tsx",
                    lineNumber: 30,
                    columnNumber: 11
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "bg-[#18181b] h-full overflow-y-auto grid grid-cols-1 auto-rows-min gap-1 pl-1 pr-1",
                    children: events.map((event, id)=>{
                        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$app$2f$components$2f$eventsNoti$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            ...event
                        }, id, false, {
                            fileName: "[project]/Creator-Control-Room/frontend/app/components/widgets/giftedWidget.tsx",
                            lineNumber: 43,
                            columnNumber: 22
                        }, this);
                    })
                }, void 0, false, {
                    fileName: "[project]/Creator-Control-Room/frontend/app/components/widgets/giftedWidget.tsx",
                    lineNumber: 41,
                    columnNumber: 11
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/Creator-Control-Room/frontend/app/components/widgets/giftedWidget.tsx",
            lineNumber: 29,
            columnNumber: 9
        }, this)
    }, void 0, false);
}
_c = GiftedWidget;
var _c;
__turbopack_context__.k.register(_c, "GiftedWidget");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/Creator-Control-Room/frontend/app/components/widgets/newFollowersWidget.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>FollowerWidget
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Creator-Control-Room/frontend/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$app$2f$components$2f$eventsNoti$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Creator-Control-Room/frontend/app/components/eventsNoti.tsx [app-client] (ecmascript)");
;
;
function FollowerWidget(param) {
    let { events, show, onAction } = param;
    const widgetClicked = ()=>{
        console.log("WIDGET SET TO DELETE");
        onAction({
            widgetName: "follow",
            widgetState: false
        });
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: show && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "w-full h-64 grid grid-rows-[auto_1fr] gap-0.5",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "bg-[#26262b] flex justify-between w-full p-2 max-h-10",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "font-bold",
                            children: "New Follower Feed"
                        }, void 0, false, {
                            fileName: "[project]/Creator-Control-Room/frontend/app/components/widgets/newFollowersWidget.tsx",
                            lineNumber: 31,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            className: "bg-[var(--button)] hover:bg-violet-500 px-3 rounded transition",
                            onClick: widgetClicked,
                            children: "delete"
                        }, void 0, false, {
                            fileName: "[project]/Creator-Control-Room/frontend/app/components/widgets/newFollowersWidget.tsx",
                            lineNumber: 32,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/Creator-Control-Room/frontend/app/components/widgets/newFollowersWidget.tsx",
                    lineNumber: 30,
                    columnNumber: 11
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "bg-[#18181b] h-full overflow-y-auto grid grid-cols-1 auto-rows-min gap-1 pl-1 pr-1",
                    children: events.map((event, id)=>{
                        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$app$2f$components$2f$eventsNoti$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            ...event
                        }, id, false, {
                            fileName: "[project]/Creator-Control-Room/frontend/app/components/widgets/newFollowersWidget.tsx",
                            lineNumber: 42,
                            columnNumber: 22
                        }, this);
                    })
                }, void 0, false, {
                    fileName: "[project]/Creator-Control-Room/frontend/app/components/widgets/newFollowersWidget.tsx",
                    lineNumber: 40,
                    columnNumber: 11
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/Creator-Control-Room/frontend/app/components/widgets/newFollowersWidget.tsx",
            lineNumber: 29,
            columnNumber: 9
        }, this)
    }, void 0, false);
}
_c = FollowerWidget;
var _c;
__turbopack_context__.k.register(_c, "FollowerWidget");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/Creator-Control-Room/frontend/app/components/widgets/subsWidget.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>SubsWidget
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Creator-Control-Room/frontend/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$app$2f$components$2f$eventsNoti$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Creator-Control-Room/frontend/app/components/eventsNoti.tsx [app-client] (ecmascript)");
;
;
function SubsWidget(param) {
    let { events, show, onAction } = param;
    const widgetClicked = ()=>{
        console.log("WIDGET SET TO DELETE");
        onAction({
            widgetName: "subscribe",
            widgetState: false
        });
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: show && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "w-full h-64 grid grid-rows-[auto_1fr] gap-0.5",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "bg-[#26262b] flex justify-between w-full p-2 max-h-10",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "font-bold",
                            children: "Subscriber Feed"
                        }, void 0, false, {
                            fileName: "[project]/Creator-Control-Room/frontend/app/components/widgets/subsWidget.tsx",
                            lineNumber: 31,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            className: "bg-[var(--button)] hover:bg-violet-500 px-3 rounded transition",
                            onClick: widgetClicked,
                            children: "delete"
                        }, void 0, false, {
                            fileName: "[project]/Creator-Control-Room/frontend/app/components/widgets/subsWidget.tsx",
                            lineNumber: 32,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/Creator-Control-Room/frontend/app/components/widgets/subsWidget.tsx",
                    lineNumber: 30,
                    columnNumber: 11
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "bg-[#18181b] h-full overflow-y-auto grid grid-cols-1 auto-rows-min gap-1 pl-1 pr-1",
                    children: events.map((event, id)=>{
                        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$app$2f$components$2f$eventsNoti$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            ...event
                        }, id, false, {
                            fileName: "[project]/Creator-Control-Room/frontend/app/components/widgets/subsWidget.tsx",
                            lineNumber: 42,
                            columnNumber: 22
                        }, this);
                    })
                }, void 0, false, {
                    fileName: "[project]/Creator-Control-Room/frontend/app/components/widgets/subsWidget.tsx",
                    lineNumber: 40,
                    columnNumber: 11
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/Creator-Control-Room/frontend/app/components/widgets/subsWidget.tsx",
            lineNumber: 29,
            columnNumber: 9
        }, this)
    }, void 0, false);
}
_c = SubsWidget;
var _c;
__turbopack_context__.k.register(_c, "SubsWidget");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/Creator-Control-Room/frontend/lib/utils.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "cn",
    ()=>cn
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Creator-Control-Room/frontend/node_modules/clsx/dist/clsx.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$tailwind$2d$merge$2f$dist$2f$bundle$2d$mjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Creator-Control-Room/frontend/node_modules/tailwind-merge/dist/bundle-mjs.mjs [app-client] (ecmascript)");
;
;
function cn() {
    for(var _len = arguments.length, inputs = new Array(_len), _key = 0; _key < _len; _key++){
        inputs[_key] = arguments[_key];
    }
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$tailwind$2d$merge$2f$dist$2f$bundle$2d$mjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["twMerge"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clsx"])(inputs));
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/Creator-Control-Room/frontend/components/ui/card.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Card",
    ()=>Card,
    "CardAction",
    ()=>CardAction,
    "CardContent",
    ()=>CardContent,
    "CardDescription",
    ()=>CardDescription,
    "CardFooter",
    ()=>CardFooter,
    "CardHeader",
    ()=>CardHeader,
    "CardTitle",
    ()=>CardTitle
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Creator-Control-Room/frontend/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Creator-Control-Room/frontend/lib/utils.ts [app-client] (ecmascript)");
;
;
function Card(param) {
    let { className, ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        "data-slot": "card",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("bg-card text-card-foreground flex flex-col gap-6 rounded-xl py-6 shadow-sm", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/Creator-Control-Room/frontend/components/ui/card.tsx",
        lineNumber: 7,
        columnNumber: 5
    }, this);
}
_c = Card;
function CardHeader(param) {
    let { className, ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        "data-slot": "card-header",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("@container/card-header grid auto-rows-min grid-rows-[auto_auto] items-start gap-1.5 px-6 has-data-[slot=card-action]:grid-cols-[1fr_auto] [.border-b]:pb-6", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/Creator-Control-Room/frontend/components/ui/card.tsx",
        lineNumber: 20,
        columnNumber: 5
    }, this);
}
_c1 = CardHeader;
function CardTitle(param) {
    let { className, ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        "data-slot": "card-title",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("leading-none font-semibold", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/Creator-Control-Room/frontend/components/ui/card.tsx",
        lineNumber: 33,
        columnNumber: 5
    }, this);
}
_c2 = CardTitle;
function CardDescription(param) {
    let { className, ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        "data-slot": "card-description",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("text-muted-foreground text-sm", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/Creator-Control-Room/frontend/components/ui/card.tsx",
        lineNumber: 43,
        columnNumber: 5
    }, this);
}
_c3 = CardDescription;
function CardAction(param) {
    let { className, ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        "data-slot": "card-action",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("col-start-2 row-span-2 row-start-1 self-start justify-self-end", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/Creator-Control-Room/frontend/components/ui/card.tsx",
        lineNumber: 53,
        columnNumber: 5
    }, this);
}
_c4 = CardAction;
function CardContent(param) {
    let { className, ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        "data-slot": "card-content",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("px-6", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/Creator-Control-Room/frontend/components/ui/card.tsx",
        lineNumber: 66,
        columnNumber: 5
    }, this);
}
_c5 = CardContent;
function CardFooter(param) {
    let { className, ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        "data-slot": "card-footer",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("flex items-center px-6 [.border-t]:pt-6", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/Creator-Control-Room/frontend/components/ui/card.tsx",
        lineNumber: 76,
        columnNumber: 5
    }, this);
}
_c6 = CardFooter;
;
var _c, _c1, _c2, _c3, _c4, _c5, _c6;
__turbopack_context__.k.register(_c, "Card");
__turbopack_context__.k.register(_c1, "CardHeader");
__turbopack_context__.k.register(_c2, "CardTitle");
__turbopack_context__.k.register(_c3, "CardDescription");
__turbopack_context__.k.register(_c4, "CardAction");
__turbopack_context__.k.register(_c5, "CardContent");
__turbopack_context__.k.register(_c6, "CardFooter");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/Creator-Control-Room/frontend/components/ui/chart.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ChartContainer",
    ()=>ChartContainer,
    "ChartLegend",
    ()=>ChartLegend,
    "ChartLegendContent",
    ()=>ChartLegendContent,
    "ChartStyle",
    ()=>ChartStyle,
    "ChartTooltip",
    ()=>ChartTooltip,
    "ChartTooltipContent",
    ()=>ChartTooltipContent
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Creator-Control-Room/frontend/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Creator-Control-Room/frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$recharts$2f$es6$2f$component$2f$ResponsiveContainer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Creator-Control-Room/frontend/node_modules/recharts/es6/component/ResponsiveContainer.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$recharts$2f$es6$2f$component$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Creator-Control-Room/frontend/node_modules/recharts/es6/component/Tooltip.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$recharts$2f$es6$2f$component$2f$Legend$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Creator-Control-Room/frontend/node_modules/recharts/es6/component/Legend.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Creator-Control-Room/frontend/lib/utils.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature(), _s2 = __turbopack_context__.k.signature(), _s3 = __turbopack_context__.k.signature();
"use client";
;
;
;
// Format: { THEME_NAME: CSS_SELECTOR }
const THEMES = {
    light: "",
    dark: ".dark"
};
const ChartContext = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"](null);
function useChart() {
    _s();
    const context = __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"](ChartContext);
    if (!context) {
        throw new Error("useChart must be used within a <ChartContainer />");
    }
    return context;
}
_s(useChart, "b9L3QQ+jgeyIrH0NfHrJ8nn7VMU=");
function ChartContainer(param) {
    let { id, className, children, config, ...props } = param;
    _s1();
    const uniqueId = __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"]();
    const chartId = "chart-".concat(id || uniqueId.replace(/:/g, ""));
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ChartContext.Provider, {
        value: {
            config
        },
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            "data-slot": "chart",
            "data-chart": chartId,
            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("[&_.recharts-cartesian-axis-tick_text]:fill-muted-foreground [&_.recharts-cartesian-grid_line[stroke='#ccc']]:stroke-border/50 [&_.recharts-curve.recharts-tooltip-cursor]:stroke-border [&_.recharts-polar-grid_[stroke='#ccc']]:stroke-border [&_.recharts-radial-bar-background-sector]:fill-muted [&_.recharts-rectangle.recharts-tooltip-cursor]:fill-muted [&_.recharts-reference-line_[stroke='#ccc']]:stroke-border flex aspect-video justify-center text-xs [&_.recharts-dot[stroke='#fff']]:stroke-transparent [&_.recharts-layer]:outline-hidden [&_.recharts-sector]:outline-hidden [&_.recharts-sector[stroke='#fff']]:stroke-transparent [&_.recharts-surface]:outline-hidden", className),
            ...props,
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ChartStyle, {
                    id: chartId,
                    config: config
                }, void 0, false, {
                    fileName: "[project]/Creator-Control-Room/frontend/components/ui/chart.tsx",
                    lineNumber: 63,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$recharts$2f$es6$2f$component$2f$ResponsiveContainer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ResponsiveContainer"], {
                    children: children
                }, void 0, false, {
                    fileName: "[project]/Creator-Control-Room/frontend/components/ui/chart.tsx",
                    lineNumber: 64,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/Creator-Control-Room/frontend/components/ui/chart.tsx",
            lineNumber: 54,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/Creator-Control-Room/frontend/components/ui/chart.tsx",
        lineNumber: 53,
        columnNumber: 5
    }, this);
}
_s1(ChartContainer, "j7NPILheLIfrWAvm8S/GM4Sml/8=");
_c = ChartContainer;
const ChartStyle = (param)=>{
    let { id, config } = param;
    const colorConfig = Object.entries(config).filter((param)=>{
        let [, config] = param;
        return config.theme || config.color;
    });
    if (!colorConfig.length) {
        return null;
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("style", {
        dangerouslySetInnerHTML: {
            __html: Object.entries(THEMES).map((param)=>{
                let [theme, prefix] = param;
                return "\n".concat(prefix, " [data-chart=").concat(id, "] {\n").concat(colorConfig.map((param)=>{
                    let [key, itemConfig] = param;
                    var _itemConfig_theme;
                    const color = ((_itemConfig_theme = itemConfig.theme) === null || _itemConfig_theme === void 0 ? void 0 : _itemConfig_theme[theme]) || itemConfig.color;
                    return color ? "  --color-".concat(key, ": ").concat(color, ";") : null;
                }).join("\n"), "\n}\n");
            }).join("\n")
        }
    }, void 0, false, {
        fileName: "[project]/Creator-Control-Room/frontend/components/ui/chart.tsx",
        lineNumber: 82,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_c1 = ChartStyle;
const ChartTooltip = __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$recharts$2f$es6$2f$component$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Tooltip"];
function ChartTooltipContent(param) {
    let { active, payload, className, indicator = "dot", hideLabel = false, hideIndicator = false, label, labelFormatter, labelClassName, formatter, color, nameKey, labelKey } = param;
    _s2();
    const { config } = useChart();
    const tooltipLabel = __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "ChartTooltipContent.useMemo[tooltipLabel]": ()=>{
            var _config_label;
            if (hideLabel || !(payload === null || payload === void 0 ? void 0 : payload.length)) {
                return null;
            }
            const [item] = payload;
            const key = "".concat(labelKey || (item === null || item === void 0 ? void 0 : item.dataKey) || (item === null || item === void 0 ? void 0 : item.name) || "value");
            const itemConfig = getPayloadConfigFromPayload(config, item, key);
            const value = !labelKey && typeof label === "string" ? ((_config_label = config[label]) === null || _config_label === void 0 ? void 0 : _config_label.label) || label : itemConfig === null || itemConfig === void 0 ? void 0 : itemConfig.label;
            if (labelFormatter) {
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("font-medium", labelClassName),
                    children: labelFormatter(value, payload)
                }, void 0, false, {
                    fileName: "[project]/Creator-Control-Room/frontend/components/ui/chart.tsx",
                    lineNumber: 146,
                    columnNumber: 9
                }, this);
            }
            if (!value) {
                return null;
            }
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("font-medium", labelClassName),
                children: value
            }, void 0, false, {
                fileName: "[project]/Creator-Control-Room/frontend/components/ui/chart.tsx",
                lineNumber: 156,
                columnNumber: 12
            }, this);
        }
    }["ChartTooltipContent.useMemo[tooltipLabel]"], [
        label,
        labelFormatter,
        payload,
        hideLabel,
        labelClassName,
        config,
        labelKey
    ]);
    if (!active || !(payload === null || payload === void 0 ? void 0 : payload.length)) {
        return null;
    }
    const nestLabel = payload.length === 1 && indicator !== "dot";
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("border-border/50 bg-background grid min-w-[8rem] items-start gap-1.5 rounded-lg border px-2.5 py-1.5 text-xs shadow-xl", className),
        children: [
            !nestLabel ? tooltipLabel : null,
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "grid gap-1.5",
                children: payload.map((item, index)=>{
                    const key = "".concat(nameKey || item.name || item.dataKey || "value");
                    const itemConfig = getPayloadConfigFromPayload(config, item, key);
                    const indicatorColor = color || item.payload.fill || item.color;
                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("[&>svg]:text-muted-foreground flex w-full flex-wrap items-stretch gap-2 [&>svg]:h-2.5 [&>svg]:w-2.5", indicator === "dot" && "items-center"),
                        children: formatter && (item === null || item === void 0 ? void 0 : item.value) !== undefined && item.name ? formatter(item.value, item.name, item, index, item.payload) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                            children: [
                                (itemConfig === null || itemConfig === void 0 ? void 0 : itemConfig.icon) ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(itemConfig.icon, {}, void 0, false, {
                                    fileName: "[project]/Creator-Control-Room/frontend/components/ui/chart.tsx",
                                    lineNumber: 200,
                                    columnNumber: 21
                                }, this) : !hideIndicator && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("shrink-0 rounded-[2px] border-(--color-border) bg-(--color-bg)", {
                                        "h-2.5 w-2.5": indicator === "dot",
                                        "w-1": indicator === "line",
                                        "w-0 border-[1.5px] border-dashed bg-transparent": indicator === "dashed",
                                        "my-0.5": nestLabel && indicator === "dashed"
                                    }),
                                    style: {
                                        "--color-bg": indicatorColor,
                                        "--color-border": indicatorColor
                                    }
                                }, void 0, false, {
                                    fileName: "[project]/Creator-Control-Room/frontend/components/ui/chart.tsx",
                                    lineNumber: 203,
                                    columnNumber: 23
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("flex flex-1 justify-between leading-none", nestLabel ? "items-end" : "items-center"),
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "grid gap-1.5",
                                            children: [
                                                nestLabel ? tooltipLabel : null,
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "text-muted-foreground",
                                                    children: (itemConfig === null || itemConfig === void 0 ? void 0 : itemConfig.label) || item.name
                                                }, void 0, false, {
                                                    fileName: "[project]/Creator-Control-Room/frontend/components/ui/chart.tsx",
                                                    lineNumber: 231,
                                                    columnNumber: 23
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/Creator-Control-Room/frontend/components/ui/chart.tsx",
                                            lineNumber: 229,
                                            columnNumber: 21
                                        }, this),
                                        item.value && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "text-foreground font-mono font-medium tabular-nums",
                                            children: item.value.toLocaleString()
                                        }, void 0, false, {
                                            fileName: "[project]/Creator-Control-Room/frontend/components/ui/chart.tsx",
                                            lineNumber: 236,
                                            columnNumber: 23
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/Creator-Control-Room/frontend/components/ui/chart.tsx",
                                    lineNumber: 223,
                                    columnNumber: 19
                                }, this)
                            ]
                        }, void 0, true)
                    }, item.dataKey, false, {
                        fileName: "[project]/Creator-Control-Room/frontend/components/ui/chart.tsx",
                        lineNumber: 188,
                        columnNumber: 13
                    }, this);
                })
            }, void 0, false, {
                fileName: "[project]/Creator-Control-Room/frontend/components/ui/chart.tsx",
                lineNumber: 181,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/Creator-Control-Room/frontend/components/ui/chart.tsx",
        lineNumber: 174,
        columnNumber: 5
    }, this);
}
_s2(ChartTooltipContent, "nRMgiGinpZEd+NE7/dAtqF0Z2iA=", false, function() {
    return [
        useChart
    ];
});
_c2 = ChartTooltipContent;
const ChartLegend = __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$recharts$2f$es6$2f$component$2f$Legend$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Legend"];
function ChartLegendContent(param) {
    let { className, hideIcon = false, payload, verticalAlign = "bottom", nameKey } = param;
    _s3();
    const { config } = useChart();
    if (!(payload === null || payload === void 0 ? void 0 : payload.length)) {
        return null;
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("flex items-center justify-center gap-4", verticalAlign === "top" ? "pb-3" : "pt-3", className),
        children: payload.map((item)=>{
            const key = "".concat(nameKey || item.dataKey || "value");
            const itemConfig = getPayloadConfigFromPayload(config, item, key);
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("[&>svg]:text-muted-foreground flex items-center gap-1.5 [&>svg]:h-3 [&>svg]:w-3"),
                children: [
                    (itemConfig === null || itemConfig === void 0 ? void 0 : itemConfig.icon) && !hideIcon ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(itemConfig.icon, {}, void 0, false, {
                        fileName: "[project]/Creator-Control-Room/frontend/components/ui/chart.tsx",
                        lineNumber: 290,
                        columnNumber: 15
                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "h-2 w-2 shrink-0 rounded-[2px]",
                        style: {
                            backgroundColor: item.color
                        }
                    }, void 0, false, {
                        fileName: "[project]/Creator-Control-Room/frontend/components/ui/chart.tsx",
                        lineNumber: 292,
                        columnNumber: 15
                    }, this),
                    itemConfig === null || itemConfig === void 0 ? void 0 : itemConfig.label
                ]
            }, item.value, true, {
                fileName: "[project]/Creator-Control-Room/frontend/components/ui/chart.tsx",
                lineNumber: 283,
                columnNumber: 11
            }, this);
        })
    }, void 0, false, {
        fileName: "[project]/Creator-Control-Room/frontend/components/ui/chart.tsx",
        lineNumber: 271,
        columnNumber: 5
    }, this);
}
_s3(ChartLegendContent, "qnidj+dVqj1Euuv2nRBc6D+LeAA=", false, function() {
    return [
        useChart
    ];
});
_c3 = ChartLegendContent;
// Helper to extract item config from a payload.
function getPayloadConfigFromPayload(config, payload, key) {
    if (typeof payload !== "object" || payload === null) {
        return undefined;
    }
    const payloadPayload = "payload" in payload && typeof payload.payload === "object" && payload.payload !== null ? payload.payload : undefined;
    let configLabelKey = key;
    if (key in payload && typeof payload[key] === "string") {
        configLabelKey = payload[key];
    } else if (payloadPayload && key in payloadPayload && typeof payloadPayload[key] === "string") {
        configLabelKey = payloadPayload[key];
    }
    return configLabelKey in config ? config[configLabelKey] : config[key];
}
;
var _c, _c1, _c2, _c3;
__turbopack_context__.k.register(_c, "ChartContainer");
__turbopack_context__.k.register(_c1, "ChartStyle");
__turbopack_context__.k.register(_c2, "ChartTooltipContent");
__turbopack_context__.k.register(_c3, "ChartLegendContent");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/Creator-Control-Room/frontend/app/components/uniqueViewsChart.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "UniqueViewsChart",
    ()=>UniqueViewsChart,
    "description",
    ()=>description
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Creator-Control-Room/frontend/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Creator-Control-Room/frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$recharts$2f$es6$2f$cartesian$2f$Bar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Creator-Control-Room/frontend/node_modules/recharts/es6/cartesian/Bar.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$recharts$2f$es6$2f$chart$2f$BarChart$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Creator-Control-Room/frontend/node_modules/recharts/es6/chart/BarChart.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$recharts$2f$es6$2f$cartesian$2f$CartesianGrid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Creator-Control-Room/frontend/node_modules/recharts/es6/cartesian/CartesianGrid.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$recharts$2f$es6$2f$cartesian$2f$XAxis$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Creator-Control-Room/frontend/node_modules/recharts/es6/cartesian/XAxis.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Creator-Control-Room/frontend/components/ui/card.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$components$2f$ui$2f$chart$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Creator-Control-Room/frontend/components/ui/chart.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
const description = "An interactive bar chart";
const chartData = [
    {
        date: "2024-04-01",
        desktop: 222,
        mobile: 150
    },
    {
        date: "2024-04-02",
        desktop: 97,
        mobile: 180
    },
    {
        date: "2024-04-03",
        desktop: 167,
        mobile: 120
    },
    {
        date: "2024-04-04",
        desktop: 242,
        mobile: 260
    },
    {
        date: "2024-04-05",
        desktop: 373,
        mobile: 290
    },
    {
        date: "2024-04-06",
        desktop: 301,
        mobile: 340
    },
    {
        date: "2024-04-07",
        desktop: 245,
        mobile: 180
    },
    {
        date: "2024-04-08",
        desktop: 409,
        mobile: 320
    },
    {
        date: "2024-04-09",
        desktop: 59,
        mobile: 110
    },
    {
        date: "2024-04-10",
        desktop: 261,
        mobile: 190
    },
    {
        date: "2024-04-11",
        desktop: 327,
        mobile: 350
    },
    {
        date: "2024-04-12",
        desktop: 292,
        mobile: 210
    },
    {
        date: "2024-04-13",
        desktop: 342,
        mobile: 380
    },
    {
        date: "2024-04-14",
        desktop: 137,
        mobile: 220
    },
    {
        date: "2024-04-15",
        desktop: 120,
        mobile: 170
    },
    {
        date: "2024-04-16",
        desktop: 138,
        mobile: 190
    },
    {
        date: "2024-04-17",
        desktop: 446,
        mobile: 360
    },
    {
        date: "2024-04-18",
        desktop: 364,
        mobile: 410
    },
    {
        date: "2024-04-19",
        desktop: 243,
        mobile: 180
    },
    {
        date: "2024-04-20",
        desktop: 89,
        mobile: 150
    },
    {
        date: "2024-04-21",
        desktop: 137,
        mobile: 200
    },
    {
        date: "2024-04-22",
        desktop: 224,
        mobile: 170
    },
    {
        date: "2024-04-23",
        desktop: 138,
        mobile: 230
    },
    {
        date: "2024-04-24",
        desktop: 387,
        mobile: 290
    },
    {
        date: "2024-04-25",
        desktop: 215,
        mobile: 250
    },
    {
        date: "2024-04-26",
        desktop: 75,
        mobile: 130
    },
    {
        date: "2024-04-27",
        desktop: 383,
        mobile: 420
    },
    {
        date: "2024-04-28",
        desktop: 122,
        mobile: 180
    },
    {
        date: "2024-04-29",
        desktop: 315,
        mobile: 240
    },
    {
        date: "2024-04-30",
        desktop: 454,
        mobile: 380
    },
    {
        date: "2024-05-01",
        desktop: 165,
        mobile: 220
    },
    {
        date: "2024-05-02",
        desktop: 293,
        mobile: 310
    },
    {
        date: "2024-05-03",
        desktop: 247,
        mobile: 190
    },
    {
        date: "2024-05-04",
        desktop: 385,
        mobile: 420
    },
    {
        date: "2024-05-05",
        desktop: 481,
        mobile: 390
    },
    {
        date: "2024-05-06",
        desktop: 498,
        mobile: 520
    },
    {
        date: "2024-05-07",
        desktop: 388,
        mobile: 300
    },
    {
        date: "2024-05-08",
        desktop: 149,
        mobile: 210
    },
    {
        date: "2024-05-09",
        desktop: 227,
        mobile: 180
    },
    {
        date: "2024-05-10",
        desktop: 293,
        mobile: 330
    },
    {
        date: "2024-05-11",
        desktop: 335,
        mobile: 270
    },
    {
        date: "2024-05-12",
        desktop: 197,
        mobile: 240
    },
    {
        date: "2024-05-13",
        desktop: 197,
        mobile: 160
    },
    {
        date: "2024-05-14",
        desktop: 448,
        mobile: 490
    },
    {
        date: "2024-05-15",
        desktop: 473,
        mobile: 380
    },
    {
        date: "2024-05-16",
        desktop: 338,
        mobile: 400
    },
    {
        date: "2024-05-17",
        desktop: 499,
        mobile: 420
    },
    {
        date: "2024-05-18",
        desktop: 315,
        mobile: 350
    },
    {
        date: "2024-05-19",
        desktop: 235,
        mobile: 180
    },
    {
        date: "2024-05-20",
        desktop: 177,
        mobile: 230
    },
    {
        date: "2024-05-21",
        desktop: 82,
        mobile: 140
    },
    {
        date: "2024-05-22",
        desktop: 81,
        mobile: 120
    },
    {
        date: "2024-05-23",
        desktop: 252,
        mobile: 290
    },
    {
        date: "2024-05-24",
        desktop: 294,
        mobile: 220
    },
    {
        date: "2024-05-25",
        desktop: 201,
        mobile: 250
    },
    {
        date: "2024-05-26",
        desktop: 213,
        mobile: 170
    },
    {
        date: "2024-05-27",
        desktop: 420,
        mobile: 460
    },
    {
        date: "2024-05-28",
        desktop: 233,
        mobile: 190
    },
    {
        date: "2024-05-29",
        desktop: 78,
        mobile: 130
    },
    {
        date: "2024-05-30",
        desktop: 340,
        mobile: 280
    },
    {
        date: "2024-05-31",
        desktop: 178,
        mobile: 230
    },
    {
        date: "2024-06-01",
        desktop: 178,
        mobile: 200
    },
    {
        date: "2024-06-02",
        desktop: 470,
        mobile: 410
    },
    {
        date: "2024-06-03",
        desktop: 103,
        mobile: 160
    },
    {
        date: "2024-06-04",
        desktop: 439,
        mobile: 380
    },
    {
        date: "2024-06-05",
        desktop: 88,
        mobile: 140
    },
    {
        date: "2024-06-06",
        desktop: 294,
        mobile: 250
    },
    {
        date: "2024-06-07",
        desktop: 323,
        mobile: 370
    },
    {
        date: "2024-06-08",
        desktop: 385,
        mobile: 320
    },
    {
        date: "2024-06-09",
        desktop: 438,
        mobile: 480
    },
    {
        date: "2024-06-10",
        desktop: 155,
        mobile: 200
    },
    {
        date: "2024-06-11",
        desktop: 92,
        mobile: 150
    },
    {
        date: "2024-06-12",
        desktop: 492,
        mobile: 420
    },
    {
        date: "2024-06-13",
        desktop: 81,
        mobile: 130
    },
    {
        date: "2024-06-14",
        desktop: 426,
        mobile: 380
    },
    {
        date: "2024-06-15",
        desktop: 307,
        mobile: 350
    },
    {
        date: "2024-06-16",
        desktop: 371,
        mobile: 310
    },
    {
        date: "2024-06-17",
        desktop: 475,
        mobile: 520
    },
    {
        date: "2024-06-18",
        desktop: 107,
        mobile: 170
    },
    {
        date: "2024-06-19",
        desktop: 341,
        mobile: 290
    },
    {
        date: "2024-06-20",
        desktop: 408,
        mobile: 450
    },
    {
        date: "2024-06-21",
        desktop: 169,
        mobile: 210
    },
    {
        date: "2024-06-22",
        desktop: 317,
        mobile: 270
    },
    {
        date: "2024-06-23",
        desktop: 480,
        mobile: 530
    },
    {
        date: "2024-06-24",
        desktop: 132,
        mobile: 180
    },
    {
        date: "2024-06-25",
        desktop: 141,
        mobile: 190
    },
    {
        date: "2024-06-26",
        desktop: 434,
        mobile: 380
    },
    {
        date: "2024-06-27",
        desktop: 448,
        mobile: 490
    },
    {
        date: "2024-06-28",
        desktop: 149,
        mobile: 200
    },
    {
        date: "2024-06-29",
        desktop: 103,
        mobile: 160
    },
    {
        date: "2024-06-30",
        desktop: 446,
        mobile: 400
    }
];
const chartConfig = {
    views: {
        label: "Page Views"
    },
    desktop: {
        label: "Desktop",
        color: "var(--chart-2)"
    },
    mobile: {
        label: "Mobile",
        color: "var(--chart-1)"
    }
};
function UniqueViewsChart() {
    _s();
    const [activeChart, setActiveChart] = __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"]("desktop");
    const total = __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "UniqueViewsChart.useMemo[total]": ()=>({
                desktop: chartData.reduce({
                    "UniqueViewsChart.useMemo[total]": (acc, curr)=>acc + curr.desktop
                }["UniqueViewsChart.useMemo[total]"], 0),
                mobile: chartData.reduce({
                    "UniqueViewsChart.useMemo[total]": (acc, curr)=>acc + curr.mobile
                }["UniqueViewsChart.useMemo[total]"], 0)
            })
    }["UniqueViewsChart.useMemo[total]"], []);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Card"], {
        className: "py-0",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CardHeader"], {
                className: "flex flex-col items-stretch border-b !p-0 sm:flex-row",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex flex-1 flex-col justify-center gap-1 px-6 pt-4 pb-3 sm:!py-0",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CardTitle"], {
                                children: "Unique Viewrs - Interactive"
                            }, void 0, false, {
                                fileName: "[project]/Creator-Control-Room/frontend/app/components/uniqueViewsChart.tsx",
                                lineNumber: 146,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CardDescription"], {
                                children: "Showing total unique visitors for the last 3 months"
                            }, void 0, false, {
                                fileName: "[project]/Creator-Control-Room/frontend/app/components/uniqueViewsChart.tsx",
                                lineNumber: 147,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/Creator-Control-Room/frontend/app/components/uniqueViewsChart.tsx",
                        lineNumber: 145,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex",
                        children: [
                            "desktop",
                            "mobile"
                        ].map((key)=>{
                            const chart = key;
                            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                "data-active": activeChart === chart,
                                className: "data-[active=true]:bg-muted/50 relative z-30 flex flex-1 flex-col justify-center gap-1 border-t px-6 py-4 text-left even:border-l sm:border-t-0 sm:border-l sm:px-8 sm:py-6",
                                onClick: ()=>setActiveChart(chart),
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-muted-foreground text-xs",
                                        children: chartConfig[chart].label
                                    }, void 0, false, {
                                        fileName: "[project]/Creator-Control-Room/frontend/app/components/uniqueViewsChart.tsx",
                                        lineNumber: 161,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-lg leading-none font-bold sm:text-3xl",
                                        children: total[key].toLocaleString()
                                    }, void 0, false, {
                                        fileName: "[project]/Creator-Control-Room/frontend/app/components/uniqueViewsChart.tsx",
                                        lineNumber: 164,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, chart, true, {
                                fileName: "[project]/Creator-Control-Room/frontend/app/components/uniqueViewsChart.tsx",
                                lineNumber: 155,
                                columnNumber: 15
                            }, this);
                        })
                    }, void 0, false, {
                        fileName: "[project]/Creator-Control-Room/frontend/app/components/uniqueViewsChart.tsx",
                        lineNumber: 151,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/Creator-Control-Room/frontend/app/components/uniqueViewsChart.tsx",
                lineNumber: 144,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CardContent"], {
                className: "px-2 sm:p-6",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$components$2f$ui$2f$chart$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ChartContainer"], {
                    config: chartConfig,
                    className: "aspect-auto h-[250px] w-full",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$recharts$2f$es6$2f$chart$2f$BarChart$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BarChart"], {
                        accessibilityLayer: true,
                        data: chartData,
                        margin: {
                            left: 12,
                            right: 12
                        },
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$recharts$2f$es6$2f$cartesian$2f$CartesianGrid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CartesianGrid"], {
                                vertical: false
                            }, void 0, false, {
                                fileName: "[project]/Creator-Control-Room/frontend/app/components/uniqueViewsChart.tsx",
                                lineNumber: 185,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$recharts$2f$es6$2f$cartesian$2f$XAxis$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["XAxis"], {
                                dataKey: "date",
                                tickLine: false,
                                axisLine: false,
                                tickMargin: 8,
                                minTickGap: 32,
                                tickFormatter: (value)=>{
                                    const date = new Date(value);
                                    return date.toLocaleDateString("en-US", {
                                        month: "short",
                                        day: "numeric"
                                    });
                                }
                            }, void 0, false, {
                                fileName: "[project]/Creator-Control-Room/frontend/app/components/uniqueViewsChart.tsx",
                                lineNumber: 186,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$components$2f$ui$2f$chart$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ChartTooltip"], {
                                content: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$components$2f$ui$2f$chart$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ChartTooltipContent"], {
                                    className: "w-[150px]",
                                    nameKey: "views",
                                    labelFormatter: (value)=>{
                                        return new Date(value).toLocaleDateString("en-US", {
                                            month: "short",
                                            day: "numeric",
                                            year: "numeric"
                                        });
                                    }
                                }, void 0, false, {
                                    fileName: "[project]/Creator-Control-Room/frontend/app/components/uniqueViewsChart.tsx",
                                    lineNumber: 202,
                                    columnNumber: 17
                                }, void 0)
                            }, void 0, false, {
                                fileName: "[project]/Creator-Control-Room/frontend/app/components/uniqueViewsChart.tsx",
                                lineNumber: 200,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$recharts$2f$es6$2f$cartesian$2f$Bar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Bar"], {
                                dataKey: activeChart,
                                fill: "var(--color-".concat(activeChart, ")")
                            }, void 0, false, {
                                fileName: "[project]/Creator-Control-Room/frontend/app/components/uniqueViewsChart.tsx",
                                lineNumber: 215,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/Creator-Control-Room/frontend/app/components/uniqueViewsChart.tsx",
                        lineNumber: 177,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/Creator-Control-Room/frontend/app/components/uniqueViewsChart.tsx",
                    lineNumber: 173,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/Creator-Control-Room/frontend/app/components/uniqueViewsChart.tsx",
                lineNumber: 172,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/Creator-Control-Room/frontend/app/components/uniqueViewsChart.tsx",
        lineNumber: 143,
        columnNumber: 5
    }, this);
}
_s(UniqueViewsChart, "FEVNlfZ370xK9kZsuuY+L0K+VV8=");
_c = UniqueViewsChart;
var _c;
__turbopack_context__.k.register(_c, "UniqueViewsChart");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/Creator-Control-Room/frontend/app/components/testAuth.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// import { generateKey } from "crypto";
// import { Dispatch, SetStateAction } from "react";
__turbopack_context__.s([
    "default",
    ()=>TestAuth
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/Creator-Control-Room/frontend/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Creator-Control-Room/frontend/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Creator-Control-Room/frontend/node_modules/next/navigation.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
function TestAuth() {
    _s();
    const params = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSearchParams"])();
    const company_id = params.get("company_id");
    const company_name = params.get("company_name");
    const CLIENT_ID = ("TURBOPACK compile-time value", "abcqzkxbrbgcv5tbc8shxyrtfe469f");
    const NEXT_PUBLIC_AUTH_REDIRECT_URI = ("TURBOPACK compile-time value", "https://a0c2b18f2a76.ngrok-free.app/auth/callback");
    const NEXT_PUBLIC_RESPONSE_TYPE = ("TURBOPACK compile-time value", "code&scope=moderator:read:followers%20channel:read:subscriptions%20bits:read");
    const uri = "https://id.twitch.tv/oauth2/authorize?client_id=".concat(CLIENT_ID, "&redirect_uri=").concat(NEXT_PUBLIC_AUTH_REDIRECT_URI, "&response_type=").concat(NEXT_PUBLIC_RESPONSE_TYPE, "&state=").concat(company_id, "|").concat(company_name);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "align-middle",
        children: [
            " ",
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                className: "p-6 bg-[var(--button)]",
                onClick: ()=>{
                    window.location.href = "".concat(uri);
                },
                children: "Test Auth Event"
            }, void 0, false, {
                fileName: "[project]/Creator-Control-Room/frontend/app/components/testAuth.tsx",
                lineNumber: 19,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/Creator-Control-Room/frontend/app/components/testAuth.tsx",
        lineNumber: 17,
        columnNumber: 5
    }, this);
}
_s(TestAuth, "wyi9mPwVuxd2gFUihxvUfxh3mM0=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSearchParams"]
    ];
});
_c = TestAuth;
var _c;
__turbopack_context__.k.register(_c, "TestAuth");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/Creator-Control-Room/frontend/app/page.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Home
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Creator-Control-Room/frontend/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Creator-Control-Room/frontend/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$app$2f$components$2f$sideBar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Creator-Control-Room/frontend/app/components/sideBar.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$app$2f$components$2f$navBar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Creator-Control-Room/frontend/app/components/navBar.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Creator-Control-Room/frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$socket$2e$io$2d$client$2f$build$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Creator-Control-Room/frontend/node_modules/socket.io-client/build/esm/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$app$2f$components$2f$generateEvents$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Creator-Control-Room/frontend/app/components/generateEvents.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$app$2f$components$2f$widgets$2f$bitsWidget$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Creator-Control-Room/frontend/app/components/widgets/bitsWidget.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$app$2f$components$2f$widgets$2f$cheerWidget$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Creator-Control-Room/frontend/app/components/widgets/cheerWidget.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$app$2f$components$2f$widgets$2f$creatorsLive$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Creator-Control-Room/frontend/app/components/widgets/creatorsLive.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$app$2f$components$2f$widgets$2f$eventsWidget$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Creator-Control-Room/frontend/app/components/widgets/eventsWidget.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$app$2f$components$2f$widgets$2f$giftedWidget$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Creator-Control-Room/frontend/app/components/widgets/giftedWidget.tsx [app-client] (ecmascript)");
// import JoinsWidget from "./components/widgets/joins24Widget";
var __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$app$2f$components$2f$widgets$2f$newFollowersWidget$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Creator-Control-Room/frontend/app/components/widgets/newFollowersWidget.tsx [app-client] (ecmascript)");
// import RaidWidget from "./components/widgets/raidWidget";
var __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$app$2f$components$2f$widgets$2f$subsWidget$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Creator-Control-Room/frontend/app/components/widgets/subsWidget.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$app$2f$components$2f$uniqueViewsChart$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Creator-Control-Room/frontend/app/components/uniqueViewsChart.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$app$2f$components$2f$testAuth$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Creator-Control-Room/frontend/app/components/testAuth.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
function Home() {
    _s();
    const socketRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const params = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSearchParams"])();
    const company_id = params.get("company_id");
    const company_name = params.get("company_name");
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const [logoData, setLogoData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [displayEventList, setDisplayEventList] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [allEvents, setAllEvents] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({});
    const [creators, setCreators] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [isLoaded, setIsLoaded] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [widgets, setWidgets] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        cheer: true,
        raid: true,
        bits: true,
        subscribe: true,
        gift: true,
        follow: true
    });
    // const fetchData = useCallback(async () => {
    //   console.log("fire");
    //   const response = await fetch(
    //     "https://a0c2b18f2a76.ngrok-free.app/db/events",
    //     {
    //       method: "POST",
    //       headers: { "Content-Type": "application/json" },
    //       body: JSON.stringify({ hi: "hello" }),
    //     }
    //   );
    //   console.log("show");
    //   const data = await response.json();
    //   console.log(data);
    //   setAllEvents((prev) => ({
    //     ...prev,
    //     [data.type]: [data, ...(prev[data.type] || [])],
    //   }));
    // }, [setAllEvents]);
    // ON HOIST USE EFFECT
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Home.useEffect": ()=>{
            if (!company_id) {
                router.push("/login");
            } else {
                // UPDATE: Turn this into a get and have data be in the endpoint
                const loadInitalData = {
                    "Home.useEffect.loadInitalData": async ()=>{
                        const response = await fetch("https://a0c2b18f2a76.ngrok-free.app/db/events", {
                            method: "POST",
                            headers: {
                                "Content-Type": "application/json"
                            },
                            body: JSON.stringify({
                                company_id: company_id
                            })
                        });
                        const response_creators_data = await fetch("https://a0c2b18f2a76.ngrok-free.app/db/get_creators", {
                            method: "POST",
                            headers: {
                                "Content-Type": "application/json"
                            },
                            body: JSON.stringify({
                                company_id: company_id
                            })
                        });
                        const creators_data = await response_creators_data.json();
                        setCreators(creators_data);
                        const response_logo_data = await fetch("https://a0c2b18f2a76.ngrok-free.app/db/company/logo", {
                            method: "POST",
                            headers: {
                                "Content-Type": "application/json"
                            },
                            body: JSON.stringify({
                                company_name: company_name
                            })
                        });
                        console.log(company_name);
                        const logo_data = await response_logo_data.json();
                        setLogoData(logo_data.url);
                        const data = await response.json();
                        if (data.res) {
                            console.log(data);
                        }
                        console.log(data);
                        for(const i in data){
                            setAllEvents({
                                "Home.useEffect.loadInitalData": (prev)=>({
                                        ...prev,
                                        [data[i].type]: [
                                            data[i],
                                            ...prev[data[i].type] || []
                                        ]
                                    })
                            }["Home.useEffect.loadInitalData"]);
                            setDisplayEventList({
                                "Home.useEffect.loadInitalData": (prev)=>[
                                        data[i],
                                        ...prev
                                    ]
                            }["Home.useEffect.loadInitalData"]);
                        }
                        setIsLoaded(true);
                    }
                }["Home.useEffect.loadInitalData"];
                if (!isLoaded) {
                    loadInitalData();
                }
            }
            if (!globalThis.__SOCKET__) {
                globalThis.__SOCKET__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$socket$2e$io$2d$client$2f$build$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["io"])("http://localhost:3001", {
                    transports: [
                        "websocket",
                        "polling"
                    ]
                });
            }
            const s = globalThis.__SOCKET__;
            socketRef.current = s;
            socketRef.current.emit("joinCompany", company_id);
            // ******SOCKET FUNCTIONS*****
            // NEW EVENT
            const onEvent = {
                "Home.useEffect.onEvent": (event)=>{
                    console.log(event);
                    setAllEvents({
                        "Home.useEffect.onEvent": (prev)=>({
                                ...prev,
                                [event.type]: [
                                    event,
                                    ...prev[event.type] || []
                                ]
                            })
                    }["Home.useEffect.onEvent"]);
                    setDisplayEventList({
                        "Home.useEffect.onEvent": (prev)=>[
                                event,
                                ...prev
                            ]
                    }["Home.useEffect.onEvent"]);
                }
            }["Home.useEffect.onEvent"];
            // SOCKET CONNECTIONS
            s.on("Event", onEvent);
            //DISCONNECT SOCKETS
            return ({
                "Home.useEffect": ()=>{
                    s.off("Event", onEvent);
                    s.disconnect();
                    console.log(socketRef.current);
                    socketRef.current = null;
                }
            })["Home.useEffect"];
        }
    }["Home.useEffect"], [
        isLoaded,
        company_id,
        company_name,
        router
    ]);
    // GENERATE AN EVENT REQUEST
    const generateTheEvent = (dataFromChild)=>{
        var _socketRef_current;
        (_socketRef_current = socketRef.current) === null || _socketRef_current === void 0 ? void 0 : _socketRef_current.emit("Event", dataFromChild);
    };
    const widgetStateChange = (param)=>{
        let { widgetName, widgetState } = param;
        console.log(widgetName, widgetState);
        setWidgets((prev)=>({
                ...prev,
                [widgetName]: widgetState
            }));
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: company_id && // Shell controls height + scrolling behavior
        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "grid grid-rows-[auto_1fr] h-[100svh] overflow-hidden text-white",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("header", {
                    className: "sticky top-0 h-14 z-50",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$app$2f$components$2f$navBar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        logourl: logoData,
                        company_name: company_name
                    }, void 0, false, {
                        fileName: "[project]/Creator-Control-Room/frontend/app/page.tsx",
                        lineNumber: 194,
                        columnNumber: 13
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/Creator-Control-Room/frontend/app/page.tsx",
                    lineNumber: 193,
                    columnNumber: 11
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "grid min-h-0 grid-cols-[16rem_1fr_18rem]",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("aside", {
                            className: "min-h-0 overflow-y-auto",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$app$2f$components$2f$sideBar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    onAction: widgetStateChange
                                }, void 0, false, {
                                    fileName: "[project]/Creator-Control-Room/frontend/app/page.tsx",
                                    lineNumber: 201,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$app$2f$components$2f$generateEvents$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    onAction: generateTheEvent
                                }, void 0, false, {
                                    fileName: "[project]/Creator-Control-Room/frontend/app/page.tsx",
                                    lineNumber: 202,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$app$2f$components$2f$testAuth$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                    fileName: "[project]/Creator-Control-Room/frontend/app/page.tsx",
                                    lineNumber: 203,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/Creator-Control-Room/frontend/app/page.tsx",
                            lineNumber: 200,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("main", {
                            className: "min-w-0 overflow-y-auto pl-0.5 pt-4.5 gap-1",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "grid-rows-[auto_auto_auto]",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "grid min-h-0 grid-cols-[auto_auto_auto] gap-0.5",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$app$2f$components$2f$widgets$2f$creatorsLive$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                creators: creators
                                            }, void 0, false, {
                                                fileName: "[project]/Creator-Control-Room/frontend/app/page.tsx",
                                                lineNumber: 210,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$app$2f$components$2f$widgets$2f$giftedWidget$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                onAction: widgetStateChange,
                                                events: allEvents["gift"] || [],
                                                show: widgets.gift
                                            }, void 0, false, {
                                                fileName: "[project]/Creator-Control-Room/frontend/app/page.tsx",
                                                lineNumber: 211,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$app$2f$components$2f$widgets$2f$cheerWidget$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                onAction: widgetStateChange,
                                                events: allEvents["cheer"] || [],
                                                show: widgets.cheer
                                            }, void 0, false, {
                                                fileName: "[project]/Creator-Control-Room/frontend/app/page.tsx",
                                                lineNumber: 216,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/Creator-Control-Room/frontend/app/page.tsx",
                                        lineNumber: 209,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "grid min-h-0 grid-cols-[auto_auto_auto] gap-0.5",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$app$2f$components$2f$widgets$2f$subsWidget$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                onAction: widgetStateChange,
                                                events: allEvents["subscribe"] || [],
                                                show: widgets.subscribe
                                            }, void 0, false, {
                                                fileName: "[project]/Creator-Control-Room/frontend/app/page.tsx",
                                                lineNumber: 223,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$app$2f$components$2f$widgets$2f$bitsWidget$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                onAction: widgetStateChange,
                                                events: allEvents["bits"] || [],
                                                show: widgets.bits
                                            }, void 0, false, {
                                                fileName: "[project]/Creator-Control-Room/frontend/app/page.tsx",
                                                lineNumber: 228,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$app$2f$components$2f$widgets$2f$newFollowersWidget$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                onAction: widgetStateChange,
                                                events: allEvents["follow"] || [],
                                                show: widgets.follow
                                            }, void 0, false, {
                                                fileName: "[project]/Creator-Control-Room/frontend/app/page.tsx",
                                                lineNumber: 233,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/Creator-Control-Room/frontend/app/page.tsx",
                                        lineNumber: 222,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$app$2f$components$2f$uniqueViewsChart$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UniqueViewsChart"], {}, void 0, false, {
                                        fileName: "[project]/Creator-Control-Room/frontend/app/page.tsx",
                                        lineNumber: 240,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/Creator-Control-Room/frontend/app/page.tsx",
                                lineNumber: 208,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/Creator-Control-Room/frontend/app/page.tsx",
                            lineNumber: 207,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("aside", {
                            className: "min-h-0 overflow-y-auto pl-0.5 pt-4.5",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$app$2f$components$2f$widgets$2f$eventsWidget$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                events: displayEventList
                            }, void 0, false, {
                                fileName: "[project]/Creator-Control-Room/frontend/app/page.tsx",
                                lineNumber: 244,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/Creator-Control-Room/frontend/app/page.tsx",
                            lineNumber: 243,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/Creator-Control-Room/frontend/app/page.tsx",
                    lineNumber: 198,
                    columnNumber: 11
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {}, void 0, false, {
                    fileName: "[project]/Creator-Control-Room/frontend/app/page.tsx",
                    lineNumber: 247,
                    columnNumber: 11
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/Creator-Control-Room/frontend/app/page.tsx",
            lineNumber: 191,
            columnNumber: 9
        }, this)
    }, void 0, false);
}
_s(Home, "a1EOx+93LNqfWdbE71IemRDrHEo=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSearchParams"],
        __TURBOPACK__imported__module__$5b$project$5d2f$Creator$2d$Control$2d$Room$2f$frontend$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"]
    ];
});
_c = Home;
var _c;
__turbopack_context__.k.register(_c, "Home");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=Creator-Control-Room_3c9a2449._.js.map