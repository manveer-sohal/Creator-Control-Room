(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_28e659f5._.js",
  "static/chunks/80260_next_dist_compiled_react-dom_32d74f1b._.js",
  "static/chunks/80260_next_dist_compiled_next-devtools_index_7380ea23.js",
  "static/chunks/80260_next_dist_compiled_de3a9f3c._.js",
  "static/chunks/80260_next_dist_client_d9e0d5f8._.js",
  "static/chunks/80260_next_dist_3cd441fd._.js",
  "static/chunks/80260_@swc_helpers_cjs_d27f7ea1._.js"
],
    source: "entry"
});
